import pygame
from settings import *
from timer import *
from support import *

class Game:
    def __init__(self):
        # ... existing code ...

        # Timer setup
        self.start_time = time.time()
        self.time_limit = 60  # Adjust as needed

        			# Calculate elapsed time
        elapsed_time = time.time() - self.start_time

            # Check if time limit is reached
         if elapsed_time >= self.time_limit:
                print("You win - You survived for 5 mins!")
                pygame.quit()sys.exit()



